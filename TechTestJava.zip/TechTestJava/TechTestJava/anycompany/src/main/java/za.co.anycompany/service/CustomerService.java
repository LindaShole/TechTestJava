package za.co.anycompany.service;

import za.co.anycompany.model.Customer;
import za.co.anycompany.model.Order;

import java.util.List;

public interface CustomerService{
    boolean placeOrder(Order order, int customerId);
    Customer findCustomerByOrderId(int orderId);
    List<Customer> findAllCustomers();

}
