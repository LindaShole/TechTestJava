package za.co.anycompany;


import za.co.anycompany.model.Order;
import za.co.anycompany.service.CustomerService;
import za.co.anycompany.service.OrderService;

public class Main {

    public static void main(String[] args) {
        OrderService orderServ  = new OrderService();

        Order order= new Order();
        order.setOrderId(1);
        order.setCustomerId(1);
        order.setAmount(550);
        order.setVAT(5.3);

       boolean isOrderPlaced= orderServ.placeOrder(order,order.getCustomerId());


    }
}
